import React, {FC, useEffect, useState} from 'react';
import {useNavigate, useParams} from "react-router-dom";
import {useDispatch} from "react-redux";
import {fetchById} from "../store/action-creators";
import {useTypedSelector} from "../hooks/useTtypedSelector";
import {ActionTypes} from "../store/types";
import Loader from "./List";

const Item: FC = () => {

    const {id} = useParams();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [productParams, setProductParams] = useState({category: null, description: null, price: null, rating: null});

    const {product} = useTypedSelector(state => state);

    useEffect(() => {
        if (id) {
            dispatch(fetchById(id));
        }
    }, []);

    useEffect(() => {
        setProductParams({
            ...productParams,
            category: product?.selectedProduct?.category,
            description: product?.selectedProduct?.description,
            price: product?.selectedProduct?.price,
            rating: product?.selectedProduct?.rating?.rate
        });
    }, [product]);

    const getBack = () => {
        navigate('/');
        dispatch({type: ActionTypes.REMOVE_SELECTED_PRODUCT});
    };

    if (!product.selectedProduct) {
        return <Loader/>
    }

    return (
        <div className='wrapper__item'>
            <div className='wrapper__item-credentials'>
                <button className='btn' onClick={getBack}>back</button>
                <h1>{product.selectedProduct.title}</h1>
            </div>
            <div className='wrapper__item-data'>
                <img src={product.selectedProduct.image} alt=''/>
                <div>
                    {productParams.category && <table>
                        <tbody>
                        {Object.entries(productParams).map(el => {
                            const [key, value] = el;
                            return (
                                <tr key={key}>
                                    <th>{key}</th>
                                    <td title={key === 'description' && value ? value : ''}><p>{value}</p></td>
                                </tr>
                            )
                        })}
                        </tbody>
                    </table>}
                </div>
            </div>
        </div>
    );
};

export default Item;
