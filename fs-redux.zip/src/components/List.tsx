import React, {FC, useEffect} from 'react';
import {useDispatch} from "react-redux";
import {fetchAll} from "../store/action-creators";
import {useTypedSelector} from "../hooks/useTtypedSelector";
import {Link} from "react-router-dom";
import Loader from "./Loader";

const List: FC = () => {

    const dispatch = useDispatch();
    const {product} = useTypedSelector(state => state);

    useEffect(() => {
        dispatch(fetchAll());
    }, []);

    if (product.loading) {
        return <Loader/>
    }

    return (
        <div className='wrapper__list'>
            {product.products.map(el => {
                return <div className='wrapper__list-item' key={el.id}>
                    <p>{el.title}</p>
                    <Link to={`/item/${el.id}`}><img src={el.image} alt='' /></Link>
                    <span>{el.category}</span>
                </div>
            })}
        </div>
    );
};

export default List;
