import {ActionTypes, ProductAction} from "../types";
import axios from "axios";
import {Dispatch} from "redux";

export const fetchAll = () => {
    return async (dispatch: Dispatch<ProductAction>) => {
        try {
            dispatch({type: ActionTypes.SET_LOADING, payload: true});
            const response = await axios.get(`https://fakestoreapi.com/products`);
            dispatch({type: ActionTypes.FETCH_PRODUCTS, payload: response.data});
        } catch (e) {}
        finally {
            dispatch({type: ActionTypes.SET_LOADING, payload: false});
        }
    }
};

export const fetchById = (id: string) => {
    return async (dispatch: Dispatch<ProductAction>) => {
        try {
            dispatch({type: ActionTypes.SET_LOADING, payload: true});
            const response = await axios.get(`https://fakestoreapi.com/products/${id}`);
            dispatch({type: ActionTypes.FETCH_SELECTED_PRODUCT, payload: response.data});
        } catch (e) {} finally {
            dispatch({type: ActionTypes.SET_LOADING, payload: false});
        }
    }
};
