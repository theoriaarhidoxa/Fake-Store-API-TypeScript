import {ActionTypes, ProductAction, ProductState} from "../types";

const initialState: ProductState = {
    loading: false,
    products: [],
    selectedProduct: {}
};

export const productReducer = (state: ProductState = initialState, action: ProductAction): ProductState => {
    switch (action.type) {
        case ActionTypes.SET_LOADING:
            return {...state, loading: action.payload};
        case ActionTypes.FETCH_PRODUCTS:
            return {...state, products: action.payload};
        case ActionTypes.FETCH_SELECTED_PRODUCT:
            return {...state, selectedProduct: action.payload};
        case ActionTypes.REMOVE_SELECTED_PRODUCT:
            return {...state, selectedProduct: null};
        default:
            return state;
    }
};
