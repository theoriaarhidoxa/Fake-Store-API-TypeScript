export enum ActionTypes {
    SET_LOADING = 'SET_LOADING',
    FETCH_PRODUCTS = 'FETCH_PRODUCTS',
    FETCH_SELECTED_PRODUCT = 'FETCH_SELECTED_PRODUCT',
    REMOVE_SELECTED_PRODUCT = 'REMOVE_SELECTED_PRODUCT'
}

export interface ProductState {
    loading: boolean;
    products: any[],
    selectedProduct: any;
}

interface SetProductsAction {
    type: ActionTypes.FETCH_PRODUCTS;
    payload: any;
}

interface SetSelectedProductAction {
    type: ActionTypes.FETCH_SELECTED_PRODUCT;
    payload: any;
}

interface RemoveSelectedProductAction {
    type: ActionTypes.REMOVE_SELECTED_PRODUCT;
}

interface SetLoading {
    type: ActionTypes.SET_LOADING;
    payload: boolean;
}

export type ProductAction = SetProductsAction | SetSelectedProductAction | RemoveSelectedProductAction | SetLoading;
